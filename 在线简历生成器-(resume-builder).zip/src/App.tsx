/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Plus, Trash2, Mail, Phone, MapPin, Link as LinkIcon, Printer } from 'lucide-react';

const generateId = () => Date.now().toString(36) + Math.random().toString(36).substring(2);

type Experience = {
  id: string;
  company: string;
  position: string;
  startDate: string;
  endDate: string;
  description: string;
};

type Education = {
  id: string;
  school: string;
  degree: string;
  startDate: string;
  endDate: string;
};

type ResumeData = {
  personalInfo: {
    name: string;
    title: string;
    email: string;
    phone: string;
    location: string;
    website: string;
    summary: string;
    photo: string;
  };
  experience: Experience[];
  education: Education[];
  skills: string;
};

const initialData: ResumeData = {
  personalInfo: {
    name: '张三',
    title: '高级前端开发工程师',
    email: 'zhangsan@example.com',
    phone: '138-1234-5678',
    location: '北京市朝阳区',
    website: 'github.com/zhangsan',
    summary: '拥有5年以上的Web前端开发经验，精通 React、Vue 等主流前端框架及工程化构建工具。具备良好的代码规范和架构设计能力，曾主导多个企业级中后台系统及移动端 H5 应用的开发与性能优化。热爱技术，对用户体验有极致追求，具备优秀的团队协作与沟通能力。',
    photo: '',
  },
  experience: [
    {
      id: generateId(),
      company: '某某科技股份有限公司',
      position: '前端开发专家',
      startDate: '2021.05',
      endDate: '至今',
      description: '• 负责公司核心业务系统的架构设计与开发，带领5人前端团队完成从0到1的重构。\n• 引入微前端架构 (qiankun)，将庞大的单体应用拆分为多个独立子应用，提升了团队开发效率与部署速度。\n• 优化首屏加载时间，通过代码分割、图片懒加载及 CDN 加速，使核心页面加载速度提升 40%。\n• 建立前端组件库，统一团队 UI 规范，沉淀了 30+ 常用业务组件。',
    },
    {
      id: generateId(),
      company: '某某互联网科技有限公司',
      position: '前端开发工程师',
      startDate: '2018.07',
      endDate: '2021.04',
      description: '• 参与公司电商平台的前端开发，负责商品详情页、购物车及结算流程的研发。\n• 使用 React + Redux 进行状态管理，配合 Ant Design 快速构建后台管理系统。\n• 负责移动端 H5 活动页面的开发，兼容主流移动设备，并使用 CSS3 实现复杂的交互动画。\n• 配合后端工程师完成 API 接口联调，保障项目按时上线。',
    }
  ],
  education: [
    {
      id: generateId(),
      school: '某某大学',
      degree: '计算机科学与技术 · 本科',
      startDate: '2014.09',
      endDate: '2018.06',
    }
  ],
  skills: '• 熟练掌握 HTML5、CSS3、JavaScript (ES6+)\n• 精通 React 及其生态 (Redux, React Router, Next.js)\n• 熟悉 Vue.js 及其生态 (Vuex, Vue Router)\n• 熟练使用 Webpack、Vite 等前端构建工具\n• 熟悉 Node.js，能使用 Express/Koa 搭建中间层\n• 熟悉 Git 版本控制，了解 CI/CD 流程',
};

// --- Reusable Form Components ---
const Input = ({ label, value, onChange, placeholder = '' }: { label: string, value: string, onChange: (v: string) => void, placeholder?: string }) => (
  <div className="mb-3">
    <label className="block text-xs font-medium text-neutral-500 mb-1">{label}</label>
    <input
      type="text"
      value={value}
      onChange={e => onChange(e.target.value)}
      placeholder={placeholder}
      className="w-full px-3 py-2 border border-neutral-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-neutral-900 bg-white"
    />
  </div>
);

const Textarea = ({ label, value, onChange, placeholder = '', rows = 3 }: { label: string, value: string, onChange: (v: string) => void, placeholder?: string, rows?: number }) => (
  <div className="mb-3">
    <label className="block text-xs font-medium text-neutral-500 mb-1">{label}</label>
    <textarea
      value={value}
      onChange={e => onChange(e.target.value)}
      placeholder={placeholder}
      rows={rows}
      className="w-full px-3 py-2 border border-neutral-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-neutral-900 resize-y bg-white"
    />
  </div>
);

const Section = ({ title, children }: { title: string, children: React.ReactNode }) => (
  <div className="mb-8">
    <h2 className="text-lg font-bold text-neutral-900 mb-4 pb-2 border-b border-neutral-200">{title}</h2>
    {children}
  </div>
);

export default function App() {
  const [data, setData] = useState<ResumeData>(initialData);
  const [activeTab, setActiveTab] = useState<'editor' | 'preview'>('editor');

  // --- State Updaters ---
  const updatePersonalInfo = (field: keyof ResumeData['personalInfo'], value: string) => {
    setData(prev => ({ ...prev, personalInfo: { ...prev.personalInfo, [field]: value } }));
  };

  const updateExperience = (id: string, field: keyof Experience, value: string) => {
    setData(prev => ({
      ...prev,
      experience: prev.experience.map(exp => exp.id === id ? { ...exp, [field]: value } : exp)
    }));
  };

  const addExperience = () => {
    setData(prev => ({
      ...prev,
      experience: [...prev.experience, { id: generateId(), company: '', position: '', startDate: '', endDate: '', description: '' }]
    }));
  };

  const removeExperience = (id: string) => {
    setData(prev => ({ ...prev, experience: prev.experience.filter(exp => exp.id !== id) }));
  };

  const updateEducation = (id: string, field: keyof Education, value: string) => {
    setData(prev => ({
      ...prev,
      education: prev.education.map(edu => edu.id === id ? { ...edu, [field]: value } : edu)
    }));
  };

  const addEducation = () => {
    setData(prev => ({
      ...prev,
      education: [...prev.education, { id: generateId(), school: '', degree: '', startDate: '', endDate: '' }]
    }));
  };

  const removeEducation = (id: string) => {
    setData(prev => ({ ...prev, education: prev.education.filter(edu => edu.id !== id) }));
  };

  return (
    <div className="min-h-screen bg-neutral-100 text-neutral-900 font-sans flex flex-col md:flex-row">
      
      {/* Mobile Tabs */}
      <div className="md:hidden flex border-b border-neutral-200 bg-white sticky top-0 z-20 print:hidden shadow-sm">
        <button
          className={`flex-1 py-3 text-sm font-medium transition-colors ${activeTab === 'editor' ? 'text-neutral-900 border-b-2 border-neutral-900' : 'text-neutral-500'}`}
          onClick={() => setActiveTab('editor')}
        >
          编辑 (Edit)
        </button>
        <button
          className={`flex-1 py-3 text-sm font-medium transition-colors ${activeTab === 'preview' ? 'text-neutral-900 border-b-2 border-neutral-900' : 'text-neutral-500'}`}
          onClick={() => setActiveTab('preview')}
        >
          预览 (Preview)
        </button>
      </div>

      {/* --- Editor Panel --- */}
      <div className={`${activeTab === 'editor' ? 'flex' : 'hidden'} md:flex w-full md:w-1/2 lg:w-1/3 bg-white border-r border-neutral-200 h-[calc(100vh-45px)] md:h-screen overflow-y-auto print:hidden flex-col`}>
        <div className="p-4 md:p-6 border-b border-neutral-200 flex justify-between items-center sticky top-0 bg-white z-10 shadow-sm">
          <h1 className="text-xl font-bold tracking-tight">简历编辑器</h1>
          <button 
            onClick={() => {
              setActiveTab('preview');
              setTimeout(() => window.print(), 100);
            }} 
            className="flex items-center gap-2 bg-neutral-900 text-white px-3 py-2 md:px-4 rounded-md hover:bg-neutral-800 transition-colors text-sm font-medium shadow-sm"
          >
            <Printer size={16} />
            <span className="hidden sm:inline">导出 PDF</span>
          </button>
        </div>
        
        <div className="p-4 md:p-6 space-y-2">
          <Section title="基本信息">
            <Input label="姓名" value={data.personalInfo.name} onChange={v => updatePersonalInfo('name', v)} />
            <Input label="求职意向/职位" value={data.personalInfo.title} onChange={v => updatePersonalInfo('title', v)} />
            <div className="grid grid-cols-2 gap-3">
              <Input label="邮箱" value={data.personalInfo.email} onChange={v => updatePersonalInfo('email', v)} />
              <Input label="电话" value={data.personalInfo.phone} onChange={v => updatePersonalInfo('phone', v)} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Input label="所在地" value={data.personalInfo.location} onChange={v => updatePersonalInfo('location', v)} />
              <Input label="个人网站/链接" value={data.personalInfo.website} onChange={v => updatePersonalInfo('website', v)} />
            </div>
            <div className="mt-3">
              <label className="block text-xs font-medium text-neutral-500 mb-1">个人照片</label>
              <div className="flex items-center gap-4">
                {data.personalInfo.photo && (
                  <img src={data.personalInfo.photo} alt="Profile" className="w-12 h-16 object-cover border border-neutral-200 rounded" />
                )}
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      const reader = new FileReader();
                      reader.onloadend = () => {
                        updatePersonalInfo('photo', reader.result as string);
                      };
                      reader.readAsDataURL(file);
                    }
                  }}
                  className="text-sm text-neutral-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-medium file:bg-neutral-100 file:text-neutral-700 hover:file:bg-neutral-200 cursor-pointer w-full"
                />
                {data.personalInfo.photo && (
                  <button onClick={() => updatePersonalInfo('photo', '')} className="text-xs text-red-500 hover:underline shrink-0">删除</button>
                )}
              </div>
            </div>
          </Section>

          <Section title="个人简介">
            <Textarea label="简介" value={data.personalInfo.summary} onChange={v => updatePersonalInfo('summary', v)} rows={4} />
          </Section>

          <Section title="工作经验">
            {data.experience.map((exp) => (
              <div key={exp.id} className="mb-6 p-4 border border-neutral-200 rounded-lg relative bg-neutral-50/50">
                <button onClick={() => removeExperience(exp.id)} className="absolute top-3 right-3 text-neutral-400 hover:text-red-500 transition-colors" title="删除">
                  <Trash2 size={16} />
                </button>
                <Input label="公司名称" value={exp.company} onChange={v => updateExperience(exp.id, 'company', v)} />
                <Input label="职位" value={exp.position} onChange={v => updateExperience(exp.id, 'position', v)} />
                <div className="grid grid-cols-2 gap-3">
                  <Input label="开始时间" value={exp.startDate} onChange={v => updateExperience(exp.id, 'startDate', v)} placeholder="如: 2021.05" />
                  <Input label="结束时间" value={exp.endDate} onChange={v => updateExperience(exp.id, 'endDate', v)} placeholder="如: 至今" />
                </div>
                <Textarea label="工作描述" value={exp.description} onChange={v => updateExperience(exp.id, 'description', v)} rows={4} />
              </div>
            ))}
            <button onClick={addExperience} className="w-full py-2.5 border-2 border-dashed border-neutral-300 text-neutral-600 rounded-lg flex items-center justify-center gap-2 hover:border-neutral-400 hover:text-neutral-900 hover:bg-neutral-50 transition-all text-sm font-medium">
              <Plus size={16} /> 添加工作经验
            </button>
          </Section>

          <Section title="教育背景">
            {data.education.map((edu) => (
              <div key={edu.id} className="mb-6 p-4 border border-neutral-200 rounded-lg relative bg-neutral-50/50">
                <button onClick={() => removeEducation(edu.id)} className="absolute top-3 right-3 text-neutral-400 hover:text-red-500 transition-colors" title="删除">
                  <Trash2 size={16} />
                </button>
                <Input label="学校名称" value={edu.school} onChange={v => updateEducation(edu.id, 'school', v)} />
                <Input label="专业与学历" value={edu.degree} onChange={v => updateEducation(edu.id, 'degree', v)} placeholder="如: 计算机科学与技术 · 本科" />
                <div className="grid grid-cols-2 gap-3">
                  <Input label="开始时间" value={edu.startDate} onChange={v => updateEducation(edu.id, 'startDate', v)} placeholder="如: 2014.09" />
                  <Input label="结束时间" value={edu.endDate} onChange={v => updateEducation(edu.id, 'endDate', v)} placeholder="如: 2018.06" />
                </div>
              </div>
            ))}
            <button onClick={addEducation} className="w-full py-2.5 border-2 border-dashed border-neutral-300 text-neutral-600 rounded-lg flex items-center justify-center gap-2 hover:border-neutral-400 hover:text-neutral-900 hover:bg-neutral-50 transition-all text-sm font-medium">
              <Plus size={16} /> 添加教育背景
            </button>
          </Section>

          <Section title="专业技能">
            <Textarea label="技能描述" value={data.skills} onChange={v => setData(prev => ({ ...prev, skills: v }))} rows={5} placeholder="列出你的核心技能..." />
          </Section>
        </div>
      </div>

      {/* --- Preview Panel --- */}
      <div className={`${activeTab === 'preview' ? 'block' : 'hidden'} md:block w-full md:w-1/2 lg:w-2/3 h-[calc(100vh-45px)] md:h-screen overflow-y-auto bg-neutral-100 p-4 md:p-8 print:p-0 print:w-full print:h-auto print:overflow-visible`}>
        {/* A4 Paper Container */}
        <div className="max-w-[210mm] min-h-[297mm] mx-auto bg-white shadow-xl print:shadow-none print:max-w-none print:min-h-0 p-8 md:p-12 print:p-8">
          
          <div className="space-y-6">
            {/* Header */}
            <div className="border-b-2 border-neutral-800 pb-5 flex justify-between items-start gap-6">
              <div className="flex-1">
                <h1 className="text-3xl md:text-4xl font-bold text-neutral-900 mb-1">{data.personalInfo.name || '姓名'}</h1>
                <h2 className="text-lg md:text-xl text-neutral-600 mb-4">{data.personalInfo.title || '职位'}</h2>
                <div className="flex flex-wrap gap-y-2 gap-x-5 text-sm text-neutral-600">
                  {data.personalInfo.email && <div className="flex items-center gap-1.5"><Mail size={14}/> {data.personalInfo.email}</div>}
                  {data.personalInfo.phone && <div className="flex items-center gap-1.5"><Phone size={14}/> {data.personalInfo.phone}</div>}
                  {data.personalInfo.location && <div className="flex items-center gap-1.5"><MapPin size={14}/> {data.personalInfo.location}</div>}
                  {data.personalInfo.website && <div className="flex items-center gap-1.5"><LinkIcon size={14}/> {data.personalInfo.website}</div>}
                </div>
              </div>
              {data.personalInfo.photo && (
                <div className="shrink-0">
                  <img src={data.personalInfo.photo} alt="Profile" className="w-24 h-32 object-cover border border-neutral-200 shadow-sm" />
                </div>
              )}
            </div>

            {/* Summary */}
            {data.personalInfo.summary && (
              <div>
                <h3 className="text-lg font-bold text-neutral-900 border-b border-neutral-300 mb-3 pb-1 uppercase tracking-widest">个人简介</h3>
                <p className="text-sm text-neutral-700 whitespace-pre-wrap leading-relaxed">{data.personalInfo.summary}</p>
              </div>
            )}

            {/* Experience */}
            {data.experience.length > 0 && (
              <div>
                <h3 className="text-lg font-bold text-neutral-900 border-b border-neutral-300 mb-4 pb-1 uppercase tracking-widest">工作经验</h3>
                <div className="space-y-5">
                  {data.experience.map(exp => (
                    <div key={exp.id}>
                      <div className="flex justify-between items-baseline mb-0.5">
                        <h4 className="font-bold text-neutral-900 text-base">{exp.company}</h4>
                        <span className="text-sm text-neutral-500 font-medium">{exp.startDate} {exp.startDate && exp.endDate ? '-' : ''} {exp.endDate}</span>
                      </div>
                      <div className="text-sm font-medium text-neutral-700 mb-2">{exp.position}</div>
                      <p className="text-sm text-neutral-600 whitespace-pre-wrap leading-relaxed">{exp.description}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Education */}
            {data.education.length > 0 && (
              <div>
                <h3 className="text-lg font-bold text-neutral-900 border-b border-neutral-300 mb-4 pb-1 uppercase tracking-widest">教育背景</h3>
                <div className="space-y-4">
                  {data.education.map(edu => (
                    <div key={edu.id}>
                      <div className="flex justify-between items-baseline mb-0.5">
                        <h4 className="font-bold text-neutral-900 text-base">{edu.school}</h4>
                        <span className="text-sm text-neutral-500 font-medium">{edu.startDate} {edu.startDate && edu.endDate ? '-' : ''} {edu.endDate}</span>
                      </div>
                      <div className="text-sm text-neutral-700">{edu.degree}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Skills */}
            {data.skills && (
              <div>
                <h3 className="text-lg font-bold text-neutral-900 border-b border-neutral-300 mb-3 pb-1 uppercase tracking-widest">专业技能</h3>
                <p className="text-sm text-neutral-700 whitespace-pre-wrap leading-relaxed">{data.skills}</p>
              </div>
            )}
          </div>

        </div>
      </div>
      
    </div>
  );
}
